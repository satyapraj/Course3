POSA-15
=======

This repository contains assignments and examples for the 2015
offering of the Pattern-Oriented Software Architecture (POSA) MOOCs
(see www.coursera.org/course/posaconcurrency and
www.coursera.org/posacommunication for more information).
